<h2>Login INSEGURO</h2>

<form action="login_inseguro.php" method="POST">
    <input type="text" name="nome" placeholder="Digite seu nome">

    <button type="submit">Entrar</button>
</form>

<h2>Login SEGURO</h2>

<form action="login_seguro.php" method="POST">
    <input type="text" name="nome" placeholder="Digite seu nome">

    <button type="submit">Entrar</button>
</form>

<address>
    <h5>KAIO GOMES DO NASCIMENTO MAZZA - DESN 2024/2 - TÉCNICO EM DESENVOLVIMENTO DE SISTEMAS</h5>
</address>