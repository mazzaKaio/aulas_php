<?php
    echo "<h1> &#128680 Área restrita &#128680 </h1>";

    echo "<p>Você não deveria estar aqui, mas conseguiu acessar devido a uma falha de segurança!</p>";

    echo "<p>Isso mostra como ataques SQL Injection podem comprometer sistemas sem proteção adequada.</p>";
?>